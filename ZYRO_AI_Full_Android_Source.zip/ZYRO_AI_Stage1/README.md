# ZYRO AI — Native Android source project

A Java 17 / AndroidX starter application for a Gemini-powered Urdu-first personal assistant.

## Build APK
1. Install Android Studio (Ladybug or newer) and Android SDK Platform 35.
2. Extract this ZIP and open the `ZYRO_AI_Stage1` folder in Android Studio.
3. Let Gradle sync. If prompted, install Android Gradle Plugin 8.6.1 dependencies.
4. Connect an Android phone with USB debugging enabled, or create an emulator.
5. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio shows the APK location when the build completes (usually `app/build/outputs/apk/debug/app-debug.apk`).

## First run
1. Open ZYRO AI > Settings.
2. Create a Gemini API key in Google AI Studio and paste it into the API key field.
3. Save the key, load supported models, choose a model, and test the connection.
4. Return to chat. Tap the microphone button and grant microphone permission to speak in Urdu.

## Included in this source
- Gemini `generateContent` integration and model discovery.
- API key encrypted with AES-GCM using Android Keystore.
- Urdu/Pakistan speech recognition intent and Android TextToSpeech Urdu voice preference (actual female voice depends on installed device TTS voices).
- Local chat transcript persistence and clear-chat action.
- Native intents to open supported apps, camera, Maps, Wi-Fi/Bluetooth/general Settings, dialer, SMS composer, and alarm screen.
- Roman Urdu-oriented JARVIS assistant prompt.

## Important limitations
- This is a real native Android project, but not unrestricted phone control. Android requires user permission and restricts background microphone access, direct calls/SMS, notification access, accessibility actions, and device settings changes.
- Calls and SMS open the system dialer/composer for the user to review; this app does not silently place calls or send messages.
- Urdu TTS quality and voice gender depend on the speech engine and voice packs installed on the phone. Install an Urdu voice pack in Android Text-to-speech settings if needed.
- Voice input uses the phone's installed speech-recognition service; Urdu availability depends on that service and network.
- Camera action opens the camera app; it does not secretly capture or upload images.
- The Gemini key is encrypted at rest on the device, but a distributed client app cannot make a user-supplied API key secret from a determined device owner. For a public commercial release, proxy Gemini requests through your own authenticated backend and apply quotas.
- No APK is included; build it locally in Android Studio so it is signed with your own debug/release key.
