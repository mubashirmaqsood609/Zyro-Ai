package com.zyro.ai;

public class GeminiConfig {
    public static final String PROVIDER_NAME = "Google Gemini API";
    public static final String BASE_URL = "https://generativelanguage.googleapis.com/v1beta";
    public static final int CONNECT_TIMEOUT_MS = 15000;
    public static final int READ_TIMEOUT_MS = 45000;
}
