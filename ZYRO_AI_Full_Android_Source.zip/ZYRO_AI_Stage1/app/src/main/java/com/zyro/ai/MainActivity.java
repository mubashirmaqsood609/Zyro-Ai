package com.zyro.ai;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements TextToSpeech.OnInitListener {
    private static final int REQ_SPEECH = 401;
    private static final int REQ_MIC = 402;
    private SecurePrefs securePrefs;
    private GeminiClient geminiClient;
    private ChatManager chatManager;
    private LinearLayout chatContainer;
    private ScrollView chatScroll;
    private EditText messageInput;
    private TextView providerStatus, latencyLabel, personalityLabel;
    private TextToSpeech tts;
    private boolean ttsReady = false, waiting = false, speakReplies = true;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        securePrefs = new SecurePrefs(this);
        geminiClient = new GeminiClient(securePrefs);
        chatManager = new ChatManager();
        tts = new TextToSpeech(this, this);
        chatContainer = findViewById(R.id.chatContainer);
        chatScroll = findViewById(R.id.chatScroll);
        messageInput = findViewById(R.id.messageInput);
        providerStatus = findViewById(R.id.providerStatus);
        latencyLabel = findViewById(R.id.latencyLabel);
        personalityLabel = findViewById(R.id.personalityLabel);

        findViewById(R.id.settingsButton).setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        findViewById(R.id.sendButton).setOnClickListener(v -> sendMessage());
        findViewById(R.id.micButton).setOnClickListener(v -> startVoiceInput());
        findViewById(R.id.clearButton).setOnClickListener(v -> clearConversation());
        restoreConversation();
        updateStatus();
    }

    @Override public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            int result = tts.setLanguage(new Locale("ur", "PK"));
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED)
                result = tts.setLanguage(new Locale("ur"));
            tts.setSpeechRate(0.96f);
            tts.setPitch(1.08f);
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED;
        }
    }

    private void say(String text) {
        if (ttsReady && text != null && !text.trim().isEmpty())
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "zyro_reply");
    }

    private void startVoiceInput() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }
        try {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK");
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ur-PK");
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "ZYRO sun rahi hai — boliye...");
            intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
            startActivityForResult(intent, REQ_SPEECH);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Is device par speech recognition service available nahi.", Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_MIC && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) startVoiceInput();
        else if (requestCode == REQ_MIC) Toast.makeText(this, "Voice ke liye microphone permission zaroori hai.", Toast.LENGTH_SHORT).show();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SPEECH && resultCode == Activity.RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                messageInput.setText(results.get(0));
                sendMessage();
            }
        }
    }

    @Override protected void onResume() { super.onResume(); updateStatus(); }

    private void updateStatus() {
        if (securePrefs == null || securePrefs.getApiKey().isEmpty()) {
            providerStatus.setText("Gemini API not configured"); providerStatus.setTextColor(0xFFFFB86B);
        } else {
            providerStatus.setText("Gemini connected · " + securePrefs.getModel()); providerStatus.setTextColor(0xFF6FE0B2);
        }
    }

    private void sendMessage() {
        if (waiting) return;
        final String message = messageInput.getText().toString().trim();
        if (message.isEmpty()) return;
        messageInput.setText("");
        addBubble("YOU", message, true);
        if (handleDeviceCommand(message)) return;
        if (securePrefs.getApiKey().isEmpty()) {
            addBubble("ZYRO", "Settings mein Gemini API key add karein, phir main jawab de sakungi.", false); return;
        }
        String model = securePrefs.getModel();
        if (model.isEmpty()) { addBubble("ZYRO", "Settings mein Gemini model select karein.", false); return; }
        String system = PersonalityManager.buildSystemInstruction(PersonalityManager.JARVIS, true, "Boss") +
                " Reply primarily in Roman Urdu (Pakistani style). You are a female assistant. Keep voice-friendly answers concise unless detail is requested.";
        String prompt = chatManager.buildPrompt(system, message);
        chatManager.addUser(message);
        waiting = true;
        latencyLabel.setText("ZYRO soch rahi hai...");
        geminiClient.generate(model, prompt, new GeminiClient.Callback() {
            @Override public void onSuccess(String text, long latencyMs) {
                waiting = false; chatManager.addModel(text); addBubble("ZYRO", text, false);
                latencyLabel.setText("Response time: " + latencyMs + " ms"); saveConversation();
                if (speakReplies) say(text);
            }
            @Override public void onError(String error, int httpCode, long latencyMs) {
                waiting = false; addBubble("ZYRO · ERROR", error, false);
                latencyLabel.setText("Request failed · " + latencyMs + " ms");
            }
        });
        saveConversation();
    }

    // Safe, user-confirmed Android intents: sensitive actions open the relevant system app for review.
    private boolean handleDeviceCommand(String raw) {
        String q = raw.toLowerCase(Locale.ROOT).trim();
        try {
            if (q.matches(".*\\b(open|kholo|khol do)\\s+(youtube|یوٹیوب).*")) return launchPackage("com.google.android.youtube", "YouTube");
            if (q.matches(".*\\b(open|kholo|khol do)\\s+(whatsapp|واٹس ایپ).*")) return launchPackage("com.whatsapp", "WhatsApp");
            if (q.matches(".*\\b(open|kholo|khol do)\\s+(chrome|browser).*")) return launchPackage("com.android.chrome", "Chrome");
            if (q.matches(".*\\b(open|kholo|khol do)\\s+(camera|کیمرا).*")) { startActivity(new Intent("android.media.action.IMAGE_CAPTURE")); return true; }
            if (q.contains("wifi settings") || q.contains("wifi kholo") || q.contains("wi-fi settings")) { startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)); return true; }
            if (q.contains("bluetooth settings") || q.contains("bluetooth kholo")) { startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); return true; }
            if (q.contains("settings kholo") || q.equals("open settings") || q.equals("phone settings")) { startActivity(new Intent(Settings.ACTION_SETTINGS)); return true; }
            if (q.matches(".*\\b(call|dial)\\s+[+0-9][0-9 -]{5,}.*")) {
                String number = q.replaceAll(".*\\b(?:call|dial)\\s+", "").replaceAll("[^+0-9].*", "").replaceAll("[^+0-9]", "");
                Intent i = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))); startActivity(i); return true;
            }
            if (q.matches(".*\\b(sms|message)\\s+[+0-9][0-9 -]{5,}.*")) {
                String number = q.replaceAll(".*\\b(?:sms|message)\\s+", "").replaceAll("[^+0-9].*", "").replaceAll("[^+0-9]", "");
                Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number))); startActivity(i); return true;
            }
            if (q.contains("alarm") || q.contains("alarm lagao")) {
                Intent i = new Intent(AlarmClock.ACTION_SHOW_ALARMS); startActivity(i); return true;
            }
            if (q.contains("maps kholo") || q.contains("open maps") || q.contains("google maps")) {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=")); startActivity(i); return true;
            }
        } catch (Exception e) { Toast.makeText(this, "Ye app/action is phone par available nahi.", Toast.LENGTH_SHORT).show(); return true; }
        return false;
    }

    private boolean launchPackage(String packageName, String label) {
        Intent launch = getPackageManager().getLaunchIntentForPackage(packageName);
        if (launch == null) { Toast.makeText(this, label + " installed nahi hai.", Toast.LENGTH_SHORT).show(); return true; }
        startActivity(launch); return true;
    }

    private void addBubble(String label, String text, boolean user) {
        LinearLayout bubble = new LinearLayout(this); bubble.setOrientation(LinearLayout.VERTICAL);
        bubble.setPadding(15, 12, 15, 12); bubble.setBackgroundResource(R.drawable.bg_panel);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(user ? (int)(getResources().getDisplayMetrics().widthPixels * 0.78f) : -1, -2);
        params.gravity = user ? Gravity.RIGHT : Gravity.LEFT; params.bottomMargin = 10; bubble.setLayoutParams(params);
        TextView title = new TextView(this); title.setText(label); title.setTextColor(user ? 0xFF36D9FF : 0xFF9B7BFF); title.setTextSize(11); title.setTypeface(null, 1);
        TextView body = new TextView(this); body.setText(text); body.setTextColor(0xFFE5EEF8); body.setTextSize(15); body.setPadding(0, 5, 0, 0);
        bubble.addView(title); bubble.addView(body); chatContainer.addView(bubble);
        chatScroll.post(() -> chatScroll.fullScroll(View.FOCUS_DOWN));
    }

    private void saveConversation() {
        try {
            JSONArray a = new JSONArray();
            // Persist the visible transcript (last 60 messages) from our in-memory view model.
            for (ChatManager.Turn t : getTurns()) { JSONObject o = new JSONObject(); o.put("role", t.role); o.put("text", t.text); a.put(o); }
            getSharedPreferences("zyro_chat", MODE_PRIVATE).edit().putString("history", a.toString()).apply();
        } catch (Exception ignored) { }
    }
    private java.util.List<ChatManager.Turn> getTurns() { return chatManager.snapshot(); }
    private void restoreConversation() {
        try {
            JSONArray a = new JSONArray(getSharedPreferences("zyro_chat", MODE_PRIVATE).getString("history", "[]"));
            int start = Math.max(0, a.length() - 60);
            for (int i = start; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i); String role = o.optString("role"), text = o.optString("text");
                if ("user".equals(role)) { chatManager.addUser(text); addBubble("YOU", text, true); }
                else { chatManager.addModel(text); addBubble("ZYRO", text, false); }
            }
        } catch (Exception ignored) { }
    }
    private void clearConversation() {
        chatManager.clear(); chatContainer.removeAllViews();
        getSharedPreferences("zyro_chat", MODE_PRIVATE).edit().remove("history").apply();
        addBubble("ZYRO", "Chat history clear kar di gayi hai.", false);
    }
    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
