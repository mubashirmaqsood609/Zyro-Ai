package com.zyro.ai;

import java.util.ArrayList;
import java.util.List;

public class ChatManager {
    public static class Turn {
        public final String role;
        public final String text;
        Turn(String role, String text) { this.role = role; this.text = text; }
    }
    private final List<Turn> history = new ArrayList<Turn>();

    public void addUser(String text) { history.add(new Turn("user", text)); }
    public void addModel(String text) { history.add(new Turn("model", text)); }
    public void clear() { history.clear(); }
    public List<Turn> snapshot() { return new ArrayList<Turn>(history); }

    public String buildPrompt(String systemInstruction, String currentText) {
        StringBuilder prompt = new StringBuilder(systemInstruction);
        prompt.append("\n\nConversation so far:\n");
        int start = Math.max(0, history.size() - 12);
        for (int i = start; i < history.size(); i++) {
            Turn turn = history.get(i);
            prompt.append(turn.role.equals("user") ? "User: " : "ZYRO: ");
            prompt.append(turn.text).append("\n");
        }
        prompt.append("User: ").append(currentText).append("\nZYRO:");
        return prompt.toString();
    }
}
