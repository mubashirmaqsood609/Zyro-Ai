package com.zyro.ai;

import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class GeminiClient {
    public interface Callback {
        void onSuccess(String text, long latencyMs);
        void onError(String message, int httpCode, long latencyMs);
    }
    public interface ModelsCallback {
        void onSuccess(List<String> models);
        void onError(String message, int httpCode);
    }

    private final SecurePrefs securePrefs;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public GeminiClient(SecurePrefs securePrefs) {
        this.securePrefs = securePrefs;
    }

    public void generate(final String model, final String prompt, final Callback callback) {
        executor.execute(new Runnable() {
            @Override public void run() {
                long start = System.currentTimeMillis();
                try {
                    String key = securePrefs.getApiKey();
                    if (key.length() == 0) throw new ApiException("Gemini API not configured", 0);
                    if (model == null || model.trim().length() == 0) throw new ApiException("Select a Gemini model in Settings.", 0);

                    JSONObject part = new JSONObject();
                    part.put("text", prompt);
                    JSONArray parts = new JSONArray();
                    parts.put(part);
                    JSONObject content = new JSONObject();
                    content.put("parts", parts);
                    JSONArray contents = new JSONArray();
                    contents.put(content);
                    JSONObject body = new JSONObject();
                    body.put("contents", contents);

                    String endpoint = GeminiConfig.BASE_URL + "/models/" +
                            URLEncoder.encode(model, "UTF-8") + ":generateContent";
                    HttpURLConnection connection = open(endpoint, key, "POST");
                    connection.setDoOutput(true);
                    connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                    byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
                    OutputStream output = connection.getOutputStream();
                    output.write(bytes);
                    output.close();

                    int code = connection.getResponseCode();
                    String response = readResponse(connection, code);
                    long latency = System.currentTimeMillis() - start;
                    if (code < 200 || code >= 300) throw new ApiException(parseApiError(response, code), code);

                    JSONObject json = new JSONObject(response);
                    JSONArray candidates = json.optJSONArray("candidates");
                    if (candidates == null || candidates.length() == 0) throw new ApiException("The API returned no response candidates.", code);
                    JSONObject contentObject = candidates.getJSONObject(0).optJSONObject("content");
                    JSONArray responseParts = contentObject == null ? null : contentObject.optJSONArray("parts");
                    StringBuilder answer = new StringBuilder();
                    if (responseParts != null) {
                        for (int i = 0; i < responseParts.length(); i++) {
                            answer.append(responseParts.getJSONObject(i).optString("text", ""));
                        }
                    }
                    if (answer.length() == 0) throw new ApiException("The API returned no text. Check model output and safety settings.", code);
                    final String result = answer.toString();
                    final long finalLatency = latency;
                    mainHandler.post(new Runnable() {
                        @Override public void run() { callback.onSuccess(result, finalLatency); }
                    });
                    connection.disconnect();
                } catch (final Exception exception) {
                    final long latency = System.currentTimeMillis() - start;
                    final int code = exception instanceof ApiException ? ((ApiException) exception).code : 0;
                    final String message = exception.getMessage() == null ? "Unknown network or API error." : exception.getMessage();
                    mainHandler.post(new Runnable() {
                        @Override public void run() { callback.onError(message, code, latency); }
                    });
                }
            }
        });
    }

    public void listModels(final ModelsCallback callback) {
        executor.execute(new Runnable() {
            @Override public void run() {
                HttpURLConnection connection = null;
                try {
                    String key = securePrefs.getApiKey();
                    if (key.length() == 0) throw new ApiException("Gemini API not configured", 0);
                    connection = open(GeminiConfig.BASE_URL + "/models?pageSize=1000", key, "GET");
                    int code = connection.getResponseCode();
                    String response = readResponse(connection, code);
                    if (code < 200 || code >= 300) throw new ApiException(parseApiError(response, code), code);
                    JSONObject json = new JSONObject(response);
                    JSONArray array = json.optJSONArray("models");
                    List<String> names = new ArrayList<String>();
                    if (array != null) {
                        for (int i = 0; i < array.length(); i++) {
                            JSONObject model = array.getJSONObject(i);
                            JSONArray methods = model.optJSONArray("supportedGenerationMethods");
                            boolean supported = false;
                            if (methods != null) {
                                for (int j = 0; j < methods.length(); j++) {
                                    if ("generateContent".equals(methods.optString(j))) supported = true;
                                }
                            }
                            String name = model.optString("name", "");
                            if (supported && name.startsWith("models/")) names.add(name.substring(7));
                        }
                    }
                    final List<String> result = names;
                    mainHandler.post(new Runnable() {
                        @Override public void run() { callback.onSuccess(result); }
                    });
                } catch (final Exception exception) {
                    final int code = exception instanceof ApiException ? ((ApiException) exception).code : 0;
                    final String message = exception.getMessage() == null ? "Unable to load models." : exception.getMessage();
                    mainHandler.post(new Runnable() {
                        @Override public void run() { callback.onError(message, code); }
                    });
                } finally {
                    if (connection != null) connection.disconnect();
                }
            }
        });
    }

    private HttpURLConnection open(String endpoint, String key, String method) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(endpoint).openConnection();
        connection.setRequestMethod(method);
        connection.setConnectTimeout(GeminiConfig.CONNECT_TIMEOUT_MS);
        connection.setReadTimeout(GeminiConfig.READ_TIMEOUT_MS);
        connection.setRequestProperty("x-goog-api-key", key);
        connection.setRequestProperty("Accept", "application/json");
        return connection;
    }

    private String readResponse(HttpURLConnection connection, int code) throws Exception {
        InputStream stream = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
        if (stream == null) return "";
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
        StringBuilder result = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) result.append(line);
        reader.close();
        return result.toString();
    }

    private String parseApiError(String body, int code) {
        try {
            JSONObject root = new JSONObject(body);
            JSONObject error = root.optJSONObject("error");
            if (error != null) return "Gemini API error " + code + ": " + error.optString("message", "Request failed.");
        } catch (Exception ignored) { }
        if (code == 401 || code == 403) return "API key rejected or access denied (HTTP " + code + "). Verify the key and project access.";
        if (code == 404) return "Model or endpoint not found (HTTP 404). Reload available models and choose one supporting generateContent.";
        if (code == 429) return "Gemini rate limit or quota exceeded (HTTP 429). Check your API quota and retry later.";
        if (code >= 500) return "Gemini service error (HTTP " + code + "). Try again later.";
        return "Gemini request failed (HTTP " + code + "). " + body;
    }

    private static class ApiException extends Exception {
        final int code;
        ApiException(String message, int code) { super(message); this.code = code; }
    }
}
