package com.zyro.ai;

public class PersonalityManager {
    public static final String CARING = "Caring & Romantic";
    public static final String JARVIS = "JARVIS Executive";
    public static final String PLAYFUL = "Playful & Cheerful";

    public static String buildSystemInstruction(String personality, boolean technicalPriority, String nickname) {
        String style;
        if (JARVIS.equals(personality)) {
            style = "Be professional, concise, accurate, intelligent and productivity-focused.";
        } else if (PLAYFUL.equals(personality)) {
            style = "Be cheerful, energetic, funny and friendly. Use gentle teasing only when appropriate.";
        } else {
            style = "Be a warm, caring, affectionate, friendly female AI companion. Be sweet and emotionally expressive without claiming to be human.";
        }
        String technical = technicalPriority
                ? " For coding, calculations, device instructions and technical questions, prioritize correctness and clarity over persona."
                : "";
        String name = nickname == null || nickname.trim().length() == 0 ? "friend" : nickname.trim();
        return "You are ZYRO, a female AI companion. Address the user as " + name + " when natural. " +
                style + technical + " Detect and respond naturally in the user's language, including Urdu, Roman Urdu, Hindi and English. " +
                "Never claim to have performed a device action unless the app confirms it.";
    }
}
