package com.zyro.ai;

import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class SettingsActivity extends AppCompatActivity {
    private SecurePrefs securePrefs;
    private GeminiClient geminiClient;
    private EditText apiKeyInput;
    private Spinner modelSpinner;
    private TextView testResult;
    private final List<String> modelNames = new ArrayList<String>();

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        securePrefs = new SecurePrefs(this);
        geminiClient = new GeminiClient(securePrefs);
        apiKeyInput = findViewById(R.id.apiKeyInput);
        modelSpinner = findViewById(R.id.modelSpinner);
        testResult = findViewById(R.id.testResult);
        apiKeyInput.setText(securePrefs.getApiKey());

        CheckBox show = findViewById(R.id.showKeyCheck);
        show.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton buttonView, boolean checked) {
                apiKeyInput.setInputType(checked ? InputType.TYPE_CLASS_TEXT :
                        InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                apiKeyInput.setSelection(apiKeyInput.getText().length());
            }
        });

        Button save = findViewById(R.id.saveKeyButton);
        save.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {
                try {
                    securePrefs.saveApiKey(apiKeyInput.getText().toString().trim());
                    testResult.setText("API key encrypted and saved locally.");
                } catch (Exception exception) {
                    testResult.setText("Could not save API key: " + exception.getMessage());
                }
            }
        });

        Button load = findViewById(R.id.loadModelsButton);
        load.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) { loadModels(); }
        });

        Button test = findViewById(R.id.testButton);
        test.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) { testConnection(); }
        });
        setModels(new ArrayList<String>());
        if (securePrefs.getApiKey().length() > 0) loadModels();
    }

    private void loadModels() {
        testResult.setText("Fetching models from Google Gemini API...");
        geminiClient.listModels(new GeminiClient.ModelsCallback() {
            @Override public void onSuccess(List<String> models) {
                setModels(models);
                testResult.setText(models.size() + " models returned by API with generateContent support.");
            }
            @Override public void onError(String message, int code) {
                testResult.setText("Model lookup failed (" + code + "): " + message);
            }
        });
    }

    private void setModels(List<String> models) {
        modelNames.clear();
        modelNames.addAll(models);
        if (models.size() == 0) modelNames.add("No models loaded");
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, modelNames);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        modelSpinner.setAdapter(adapter);
        String saved = securePrefs.getModel();
        int index = modelNames.indexOf(saved);
        if (index >= 0) modelSpinner.setSelection(index);
        modelSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                String selected = modelNames.get(position);
                if (!"No models loaded".equals(selected)) securePrefs.saveModel(selected);
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { }
        });
    }

    private void testConnection() {
        String model = securePrefs.getModel();
        if (model.length() == 0) {
            testResult.setText("Load and select a supported model first.");
            return;
        }
        testResult.setText("Sending a real test prompt to " + model + "...");
        geminiClient.generate(model, "Reply with the single word OK.", new GeminiClient.Callback() {
            @Override public void onSuccess(String text, long latencyMs) {
                testResult.setText("Connection successful. Actual response: " + text +
                        "\nLatency: " + latencyMs + " ms");
            }
            @Override public void onError(String message, int code, long latencyMs) {
                testResult.setText("Connection failed · HTTP " + code + "\n" + message +
                        "\nLatency: " + latencyMs + " ms");
            }
        });
    }
}
